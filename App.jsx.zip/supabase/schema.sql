-- SonoLane — core backend schema (profiles + friends)
--
-- HOW TO RUN THIS:
--   1. Open your Supabase project → SQL Editor (left sidebar)
--   2. Click "New query", paste this entire file in, click "Run"
--   3. That's it — the tables, security rules, and triggers below are all
--      created in one shot.
--
-- SCOPE: this covers real accounts + profiles + friends, matching the
-- "core first" plan. Lanes chat, shared garages, routes/events, and
-- achievements/points stay on the app's existing simulated local data for
-- now and can be migrated the same way later.

-- ─────────────────────────────────────────────────────────────────────────
-- 1. PROFILES
-- One row per signed-up user, keyed to Supabase's built-in auth.users table.
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null default '',
  handle      text unique,                 -- lowercase, no spaces — e.g. "mia.drifts"
  region      text not null default '',    -- e.g. "Los Angeles, CA" — collected at sign-up
  bio         text not null default '',
  photo_url   text,                        -- data URL for now; swap for Supabase Storage later
  initials    text not null default '',
  color       text not null default '#f97316',
  created_at  timestamptz not null default now()
);

-- Re-running this file on a project that already has the profiles table
-- (from before "region" existed) just adds the missing column — safe to
-- run again any time.
alter table public.profiles add column if not exists region text not null default '';

alter table public.profiles enable row level security;

-- Anyone signed in can read basic profile info — needed so the Friends
-- page's "search people by name" can find other real users, the same way
-- it searched the old simulated directory.
create policy "Profiles are readable by any signed-in user"
  on public.profiles for select
  to authenticated
  using (true);

-- You can only ever edit or create your own profile row.
create policy "Users can insert their own profile"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Auto-create a profile row the moment someone signs up, so the app never
-- has to worry about a missing profiles row for a logged-in user. Picks up
-- the name/region the sign-up screen collects (passed as auth user
-- metadata) so Edit Profile isn't blank on first log-in; falls back to
-- blank/email-derived defaults if metadata wasn't sent (e.g. older clients).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, name, region, initials, color)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', ''),
    coalesce(new.raw_user_meta_data->>'region', ''),
    upper(left(coalesce(nullif(new.raw_user_meta_data->>'name', ''), new.email, 'U'), 2)),
    ('#' || substr(md5(new.id::text), 1, 6))
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ─────────────────────────────────────────────────────────────────────────
-- 2. FRIENDS
-- One row = "owner_id added friend_id as a friend". The app reads the
-- first 3 rows (by created_at) as someone's "Top 3 Friends", exactly like
-- the old local array's first three slots.
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.friends (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  friend_id   uuid not null references public.profiles(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (owner_id, friend_id),
  check (owner_id <> friend_id)
);

-- If this table was created before this line existed, its foreign keys
-- point at auth.users instead of public.profiles. That's not just a style
-- difference — PostgREST can only follow the embedded-select syntax the
-- app uses (profiles:friend_id(...)) across a foreign key that points at
-- another table IN THE SAME EXPOSED SCHEMA. A friends → auth.users key
-- doesn't count, even though profiles.id also happens to reference
-- auth.users — so that embedded query silently returned nothing, the app
-- never re-populated your friends list on reload, and it looked like
-- friends just weren't being saved. Re-running this file repoints both
-- keys at public.profiles, which fixes it going forward.
alter table public.friends drop constraint if exists friends_owner_id_fkey;
alter table public.friends add constraint friends_owner_id_fkey
  foreign key (owner_id) references public.profiles(id) on delete cascade;
alter table public.friends drop constraint if exists friends_friend_id_fkey;
alter table public.friends add constraint friends_friend_id_fkey
  foreign key (friend_id) references public.profiles(id) on delete cascade;

alter table public.friends enable row level security;

-- You can only see, add to, and remove from your own friends list.
create policy "Users can read their own friends list"
  on public.friends for select
  to authenticated
  using (auth.uid() = owner_id);

create policy "Users can add their own friends"
  on public.friends for insert
  to authenticated
  with check (auth.uid() = owner_id);

create policy "Users can remove their own friends"
  on public.friends for delete
  to authenticated
  using (auth.uid() = owner_id);

-- Helpful index for "give me this user's friends, oldest first" (= Top 3).
create index if not exists friends_owner_created_idx
  on public.friends (owner_id, created_at);

-- ─────────────────────────────────────────────────────────────────────────
-- 3. MESSAGES
-- Direct messages between two friends (Lanes' "Direct Messages" list).
-- Lane/CB-radio chat rooms themselves stay local/simulated for now — this
-- table is only for 1:1 messages, which is the part that needs to actually
-- reach the other person.
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.messages (
  id           uuid primary key default gen_random_uuid(),
  sender_id    uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  text         text not null,
  created_at   timestamptz not null default now(),
  check (sender_id <> recipient_id)
);

alter table public.messages enable row level security;

-- You can read a message if you sent it or received it — nothing else.
create policy "Users can read their own conversations"
  on public.messages for select
  to authenticated
  using (auth.uid() = sender_id or auth.uid() = recipient_id);

create policy "Users can send messages as themselves"
  on public.messages for insert
  to authenticated
  with check (auth.uid() = sender_id);

create index if not exists messages_sender_recipient_idx
  on public.messages (sender_id, recipient_id, created_at);
create index if not exists messages_recipient_sender_idx
  on public.messages (recipient_id, sender_id, created_at);

-- ─────────────────────────────────────────────────────────────────────────
-- 4. NOTIFICATIONS
-- Powers the 🔔 notifications lane — friend-adds and new messages insert a
-- row here for the OTHER person, so it's normal for an insert to name
-- someone other than the signed-in user as the recipient.
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.notifications (
  id           uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id     uuid references public.profiles(id) on delete set null, -- who caused it, if anyone
  icon         text not null default '🔔',
  text         text not null,
  read         boolean not null default false,
  created_at   timestamptz not null default now()
);

alter table public.notifications enable row level security;

-- You can only ever read/mark-read your OWN notifications feed.
create policy "Users can read their own notifications"
  on public.notifications for select
  to authenticated
  using (auth.uid() = recipient_id);

create policy "Users can mark their own notifications read"
  on public.notifications for update
  to authenticated
  using (auth.uid() = recipient_id)
  with check (auth.uid() = recipient_id);

-- Any signed-in user can create a notification FOR someone else — that's
-- how "so-and-so added you as a friend" or "you got a message" reach the
-- other person's feed. It only ever grants writing into someone else's
-- notifications, never reading them.
create policy "Users can create a notification for anyone"
  on public.notifications for insert
  to authenticated
  with check (true);

create index if not exists notifications_recipient_created_idx
  on public.notifications (recipient_id, created_at desc);
